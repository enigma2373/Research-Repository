from tkinter import *
def add():
    v1 = ent_number1.get()
    v2 = ent_number2.get()
    lab_answer1 = Label(root, text=float(v1)+float(v2), font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

def subtraction():
    v1 = ent_number1.get()
    v2 = ent_number2.get()
    lab_answer1 = Label(root, text=float(v1)-float(v2), font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

def multiply():
    v1 = ent_number1.get()
    v2 = ent_number2.get()
    lab_answer1 = Label(root, text=float(v1)*float(v2), font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

def divide():
    v1 = ent_number1.get()
    v2 = ent_number2.get()
    lab_answer1 = Label(root, text=float(v1)/float(v2), font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

def cmtoin():
    v3 = ent_number3.get()
    lab_answer1 = Label(root, text=float(v3)/2.54, font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

def intocm():
    v3 = ent_number3.get()
    lab_answer1 = Label(root, text=float(v3)*2.54, font=('arial', 14), bg='white', width=20)
    canvas1.create_window(150, 350, window=lab_answer1)

root = Tk()
root.title('Calculator')

# Background Image
bg = PhotoImage(file = "background-gradient.png")

canvas1 = Canvas( root, width = 350,
                 height = 400)
canvas1.pack(fill = "both", expand = True)

canvas1.create_image( 0, 0, image = bg, 
                     anchor = "nw")

lab_number1 = Label(root, text='First number')
lab_number1.config(font=('arial', 10), bg='darkgrey')
canvas1.create_window(60, 40, window=lab_number1)

ent_number1 = Entry(root)
canvas1.create_window(200, 40, window=ent_number1)

lab_number2 = Label(root, text='Second number')
lab_number2.config(font=('arial', 10), bg='darkgrey')
canvas1.create_window(69, 80, window=lab_number2)

ent_number2 = Entry(root)
canvas1.create_window(200, 80, window=ent_number2)

lab_number3 = Label(root, text='Convert number')
lab_number3.config(font=('arial', 10), bg='lightblue')
canvas1.create_window(69, 120, window=lab_number3)

ent_number3 = Entry(root)
canvas1.create_window(200, 120, window=ent_number3)

lab_answer = Label(root, text='Answer')
lab_answer.config(font=('arial', 18), bg='lightblue')
canvas1.create_window(69, 300, window=lab_answer)

lab_answer1 = Label(root, text='0.0')
lab_answer1.config(font=('arial', 14), bg='white')
canvas1.create_window(150, 350, window=lab_answer1)

but_add = Button(text='+', command=add, bg='light grey', fg='black', font=('arial', 18), width=4)
canvas1.create_window(220, 200, window=but_add)

but_sub = Button(text='-', command=subtraction, bg='light grey', fg='black', font=('arial', 18), width=4)
canvas1.create_window(220, 260, window=but_sub)

but_multiply = Button(text='×', command=multiply, bg='light grey', fg='black', font=('arial', 18), width=4)
canvas1.create_window(300, 200, window=but_multiply)

but_divide = Button(text='÷', command=divide, bg='light grey', fg='black', font=('arial', 18), width=4)
canvas1.create_window(300, 260, window=but_divide)


but_cmtoin = Button(text='cm to in', command=cmtoin, bg='Light Grey', fg='black', font=('arial', 18), width=6)
canvas1.create_window(69, 180, window=but_cmtoin)

but_intocm = Button(text='in to cm', command=intocm, bg='Light Grey', fg='black', font=('arial', 18), width=6)
canvas1.create_window(69, 240, window=but_intocm)
root.mainloop()