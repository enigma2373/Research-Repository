""""Added 03_age_validator_v2"""


# Import Statements

# Functions go here

# Check that the ticket name is not blank
def not_blank(question):
    valid = ""
    while True:
        response = input(question).title()
        if not response.isalpha():
            print("You cant leave this blank...")
        else:
            return response


def number_checker(text):
    valid = False
    while not valid:
        try:
            number_to_check = int(input(text))
            if isinstance(number_to_check, int):
                valid = True
                return number_to_check
        except ValueError:
            print("\nPlease enter an integer (i.e. a whole number with no decimals)")


# Main Routine

# Set up dictionaries / lists needed to hold data

# Ask user if they have used the program before and
# show instructions if necessary

# Loop to get ticket details
name = ""
count = 0
MAX_TICKETS = 5
TICKET_COST_PRICE = 5.00

while name != "Xxx" and count != 5:
    print(f"You have {MAX_TICKETS - count} seat(s) left")
    # Get details
    name = not_blank("What is your name? ")
    count += 1

    if count < MAX_TICKETS:
        print(f"\nYou have sold {count} tickets\nthere are sill "
              f"{MAX_TICKETS - count} available")

    else:
        print("\nYou have sold all the available tickets")
        # Get name (can't be blank)
        name = not_blank("What is your name: ", )
        if name != "Xxx":
            break
        else:
            age = number_checker("\nPlease enter the age of the ticket holder: ")
            while not 12 <= age <= 110:
                age = number_checker("\n Please enter an integer between 12 and 110: ")
        print(f"age = {age}")

    # Get age (between 12 and 110)
    age = number_checker("\nPlease enter the age of the ticket holder: ")
    while not 12 <= age <= 110:
        age = number_checker("\n Please enter an integer between 12 and 110: ")
        print(f"age = {age}")

    # Calc price
    def calculate_ticket_price(age):
        child_age = range(12, 16)
        standard_age = range(16, 65)

        child_price = 7.5
        standard_price = 10.5
        retired_price = 6.5

        if age in child_age:
            ticket_price = child_price
        elif age in standard_age:
            ticket_price = standard_price
        else:
            ticket_price = retired_price

            ticket_price = calculate_ticket_price()
        print(f"For {test_name} the price is ${calculate_ticket_price(test_age):,.2f}")
        profit += (ticket_price - TICKET_COST_PRICE)


    # Loop to ask for snacks

    # Calc snack price

    # Ask for payment method (and apply surcharge if necessary)

# calc total sales and profit

# output data to text file
