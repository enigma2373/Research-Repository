"""This version includes a print statement of how many tickets available before purchasing"""

# Initialise loop so that it runs at least once
name = ""
count = 0
MAX_TICKETS = 5

while name != "Xxx" and count != 5:
    print(f"You have {MAX_TICKETS - count} seat(s) left")
    # Get details
    name = input("What is your name? ").title()
    count += 1

if count < MAX_TICKETS:
    print(f"\nYou have sold {count} tickets\nthere are sill "
          f"{MAX_TICKETS - count } available")

else:
    print("\nYou have sold all the available tickets")
