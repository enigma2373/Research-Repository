"""asks for a Yes/No responce and keeps asking until a correct responce is given"""

error_message = "please answer 'Y' or 'N'"
valid_responses = ["y", "yes", "n", "no"]
response = input("Do you want snacks").lower()
while response not in valid_responses:
    print(error_message)
    response = input("Do you want snacks: ").lower()

if response == "n" or response == "no":
    print("Valid Answer. You don't want snacks")
else:
    print("valid answer, you want snacks")

