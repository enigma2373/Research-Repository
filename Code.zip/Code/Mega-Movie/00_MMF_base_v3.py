""""Added 02_Ticket_loop_v2"""

# Import Statements

# Functions go here

# Check that the ticket name is not blank
def not_blank(question):
    valid = ""
    while True:
        response = input(question).title()
        if not response.isalpha():
            print("You cant leave this blank...")
        else:
            return response

# Main Routine

# Set up dictionaries / lists needed to hold data

# Ask user if they have used the program before and
# show instructions if necessary

# Loop to get ticket details
name = ""
count = 0
MAX_TICKETS = 5

while name != "Xxx" and count != 5:
    print(f"You have {MAX_TICKETS - count} seat(s) left")
    # Get details
    name = not_blank("What is your name? ")
    count += 1

if count < MAX_TICKETS:
    print(f"\nYou have sold {count} tickets\nthere are sill "
          f"{MAX_TICKETS - count } available")

else:
    print("\nYou have sold all the available tickets")
    # Get name (can't be blank)
    name = not_blank("What is your name: ", )

    # Get age (between 12 and 130)

    # Calc price

    # Loop to ask for snacks

    # Calc snack price

    # Ask for payment method (and apply surcharge if necessary)

# calc total sales and profit

# output data to text file
