# Import Statements

# Functions go here

# Main Routine

# Set up dictionaries / lists needed to hold data

# Ask user if they have used the program before and
# show instructions if necessary

# Loop to get ticket details

    # Get name (can't be blank)

    # Get age (between 12 and 130)

    # Calc price

    # Loop to ask for snacks

    # Calc snack price

    # Ask for payment method (and apply surcharge if necessary)

# calc total sales and profit

# output data to text file
