""""Added 01_name_not_blank_v3 to original v1 of this base code"""

# Import Statements

# Functions go here

# Check that the ticket name is not blank
def not_blank(question):
    valid = ""
    while True:
        response = input(question)
        if not response.isalpha():
            print("You cant leave this blank...")
        else:
            return response

# Main Routine

# Set up dictionaries / lists needed to hold data

# Ask user if they have used the program before and
# show instructions if necessary

# Loop to get ticket details

    # Get name (can't be blank)
    name = not_blank("What is your name: ", )

    # Get age (between 12 and 130)

    # Calc price

    # Loop to ask for snacks

    # Calc snack price

    # Ask for payment method (and apply surcharge if necessary)

# calc total sales and profit

# output data to text file
